package com.example.demo.entity;

public class OrderSpeedDateSum {
private int SumOrder;
private 
}
