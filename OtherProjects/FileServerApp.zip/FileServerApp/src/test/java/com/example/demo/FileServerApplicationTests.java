package com.example.demo;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class FileServerApplicationTests {

	@Test
	void contextLoads() {
	}
	
	Logger logger = LoggerFactory.getLogger((getClass()));
	

	
	@Test
	//@Transactional
	public void test3()
	{
	}

}
